<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    use HasFactory;

    protected $fillable = [
        'sub_element_id',
        'name',
        'description',
    ];

    public function subElement()
    {
        return $this->belongsTo(SubElement::class);
    }
}
